# publicacoesdeolinda
a website made for Publicações de Olinda, a crowdfunding editorial book publication based in Brazil. 

ENG
I used html/css only to create a simple and elegant website. My client asked me to make it the most simple I could do, using black, 
white and grey colors to imitate portfolios and the white cube of art galleries. 

PT
Usei html/css apenas para criar um site simples e elegante. Meu cliente me pediu para fazer o mais simples possível, usando preto,
cores brancas e cinzas para imitar portfólios e o cubo branco das galerias de arte.

